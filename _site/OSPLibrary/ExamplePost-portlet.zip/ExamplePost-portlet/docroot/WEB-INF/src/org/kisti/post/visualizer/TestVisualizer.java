package org.kisti.post.visualizer;

import com.kisti.osp.service.OSPFileLocalServiceUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

/**
 * Portlet implementation class TestVisualizer
 */
public class TestVisualizer extends MVCPortlet {

	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		// TODO Auto-generated method stub
		//super.serveResource(resourceRequest, resourceResponse);
		OSPFileLocalServiceUtil.processOSPResourceAction(resourceRequest, resourceResponse);
	}

}
